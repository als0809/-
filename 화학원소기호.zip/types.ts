
export interface ElementData {
  number: number;
  symbol: string;
  nameEn: string;
  nameKr: string;
  category: string;
  color: string;
}

export type CardType = 'symbol' | 'name';

export interface CardInstance {
  id: string;
  elementNumber: number;
  content: string;
  type: CardType;
  isFlipped: boolean;
  isMatched: boolean;
}

export enum GameDifficulty {
  EASY = 'EASY', // 1-10
  MEDIUM = 'MEDIUM', // 1-20
  HARD = 'HARD' // 1-30
}

export interface GameStats {
  moves: number;
  matches: number;
  timeElapsed: number;
}
