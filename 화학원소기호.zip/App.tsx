
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ELEMENTS } from './constants';
import { CardInstance, CardType, GameDifficulty, GameStats } from './types';
import { getElementFact } from './services/geminiService';

// Utility to shuffle array
const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

const App: React.FC = () => {
  const [difficulty, setDifficulty] = useState<GameDifficulty>(GameDifficulty.EASY);
  const [cards, setCards] = useState<CardInstance[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [stats, setStats] = useState<GameStats>({ moves: 0, matches: 0, timeElapsed: 0 });
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'FINISHED'>('IDLE');
  const [currentFact, setCurrentFact] = useState<string | null>(null);
  const [loadingFact, setLoadingFact] = useState(false);
  
  const timerRef = useRef<number | null>(null);

  const initGame = useCallback((diff: GameDifficulty) => {
    let limit = 10;
    if (diff === GameDifficulty.MEDIUM) limit = 20;
    if (diff === GameDifficulty.HARD) limit = 30;

    const selectedElements = ELEMENTS.slice(0, limit);
    const newCards: CardInstance[] = [];

    selectedElements.forEach((el) => {
      // Create Symbol Card
      newCards.push({
        id: `symbol-${el.number}`,
        elementNumber: el.number,
        content: el.symbol,
        type: 'symbol',
        isFlipped: false,
        isMatched: false,
      });
      // Create Name Card
      newCards.push({
        id: `name-${el.number}`,
        elementNumber: el.number,
        content: el.nameKr,
        type: 'name',
        isFlipped: false,
        isMatched: false,
      });
    });

    setCards(shuffleArray(newCards));
    setFlippedCards([]);
    setStats({ moves: 0, matches: 0, timeElapsed: 0 });
    setGameState('PLAYING');
    setCurrentFact(null);

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => {
      setStats((prev) => ({ ...prev, timeElapsed: prev.timeElapsed + 1 }));
    }, 1000);
  }, []);

  const handleCardClick = async (index: number) => {
    if (gameState !== 'PLAYING') return;
    if (cards[index].isFlipped || cards[index].isMatched) return;
    if (flippedCards.length === 2) return;

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setStats((prev) => ({ ...prev, moves: prev.moves + 1 }));
      const [idx1, idx2] = newFlipped;
      
      if (newCards[idx1].elementNumber === newCards[idx2].elementNumber) {
        // Match found!
        setTimeout(async () => {
          const matchedCards = [...newCards];
          matchedCards[idx1].isMatched = true;
          matchedCards[idx2].isMatched = true;
          setCards(matchedCards);
          setFlippedCards([]);
          setStats((prev) => {
            const newMatches = prev.matches + 1;
            if (newMatches === cards.length / 2) {
              setGameState('FINISHED');
              if (timerRef.current) clearInterval(timerRef.current);
            }
            return { ...prev, matches: newMatches };
          });

          // Fetch fact from Gemini for the matched element
          const element = ELEMENTS.find(e => e.number === newCards[idx1].elementNumber);
          if (element) {
            setLoadingFact(true);
            const fact = await getElementFact(element.nameKr, element.symbol);
            setCurrentFact(fact);
            setLoadingFact(false);
          }
        }, 500);
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...newCards];
          resetCards[idx1].isFlipped = false;
          resetCards[idx2].isFlipped = false;
          setCards(resetCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col items-center bg-slate-900 overflow-x-hidden">
      {/* Header */}
      <header className="w-full max-w-4xl flex flex-col md:flex-row justify-between items-center mb-8 gap-4 bg-slate-800 p-6 rounded-2xl shadow-xl border border-slate-700">
        <div>
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-emerald-400">
            Chemistry Card Master
          </h1>
          <p className="text-slate-400 text-sm mt-1">원소기호 1~30번 마스터하기!</p>
        </div>
        
        <div className="flex gap-4">
          <div className="bg-slate-700/50 px-4 py-2 rounded-xl text-center min-w-[80px]">
            <p className="text-[10px] uppercase text-slate-400 font-bold">Moves</p>
            <p className="text-xl font-mono text-blue-300">{stats.moves}</p>
          </div>
          <div className="bg-slate-700/50 px-4 py-2 rounded-xl text-center min-w-[80px]">
            <p className="text-[10px] uppercase text-slate-400 font-bold">Time</p>
            <p className="text-xl font-mono text-emerald-300">{formatTime(stats.timeElapsed)}</p>
          </div>
          <div className="bg-slate-700/50 px-4 py-2 rounded-xl text-center min-w-[80px]">
            <p className="text-[10px] uppercase text-slate-400 font-bold">Matches</p>
            <p className="text-xl font-mono text-pink-300">{stats.matches} / {cards.length / 2 || '-'}</p>
          </div>
        </div>
      </header>

      {/* Facts Banner */}
      <div className="w-full max-w-4xl mb-6 min-h-[80px]">
        {loadingFact ? (
          <div className="w-full h-full flex items-center justify-center animate-pulse bg-slate-800/50 rounded-xl border border-blue-500/20 p-4">
            <span className="text-blue-400 italic">원소 상식을 불러오는 중...</span>
          </div>
        ) : currentFact ? (
          <div className="w-full h-full flex items-center gap-4 bg-slate-800 border-l-4 border-blue-500 rounded-r-xl p-4 shadow-lg animate-fadeIn">
            <div className="text-2xl text-blue-400"><i className="fas fa-lightbulb"></i></div>
            <p className="text-slate-200 leading-relaxed text-sm md:text-base">
              {currentFact}
            </p>
          </div>
        ) : null}
      </div>

      {/* Main Board */}
      <main className="w-full max-w-6xl">
        {gameState === 'IDLE' ? (
          <div className="flex flex-col items-center justify-center gap-8 py-12">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-3xl">
              {[
                { type: GameDifficulty.EASY, label: '쉬움', range: '1-10', color: 'from-green-500 to-emerald-600' },
                { type: GameDifficulty.MEDIUM, label: '보통', range: '1-20', color: 'from-blue-500 to-indigo-600' },
                { type: GameDifficulty.HARD, label: '어려움', range: '1-30', color: 'from-purple-500 to-pink-600' },
              ].map((lvl) => (
                <button
                  key={lvl.type}
                  onClick={() => initGame(lvl.type)}
                  className={`group relative overflow-hidden bg-gradient-to-br ${lvl.color} p-6 rounded-2xl shadow-lg hover:scale-105 transition-all duration-300 text-white`}
                >
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold mb-1">{lvl.label}</h3>
                    <p className="opacity-80">원소번호 {lvl.range}</p>
                  </div>
                  <div className="absolute -right-4 -bottom-4 opacity-20 transform group-hover:rotate-12 transition-transform">
                    <i className="fas fa-atom text-7xl"></i>
                  </div>
                </button>
              ))}
            </div>
            <div className="text-slate-500 max-w-md text-center">
              <p>원소 기호와 원소 이름을 짝지어 보세요. 모든 짝을 맞추면 성공!</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div className={`grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-10 gap-2 md:gap-4 w-full mb-8`}>
              {cards.map((card, idx) => (
                <Card 
                  key={card.id} 
                  card={card} 
                  onClick={() => handleCardClick(idx)}
                />
              ))}
            </div>
            
            <button 
              onClick={() => setGameState('IDLE')}
              className="px-8 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-full transition-colors flex items-center gap-2 shadow-lg mb-8"
            >
              <i className="fas fa-undo"></i>
              게임 다시 설정
            </button>
          </div>
        )}
      </main>

      {/* Completion Modal */}
      {gameState === 'FINISHED' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 border-2 border-emerald-500 rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl animate-bounceIn">
            <div className="text-6xl text-emerald-500 mb-4">
              <i className="fas fa-trophy"></i>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">대단해요!</h2>
            <p className="text-slate-400 mb-6">모든 원소를 완벽하게 마스터했습니다.</p>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-slate-900/50 p-4 rounded-xl">
                <p className="text-xs text-slate-500 uppercase font-bold">총 시간</p>
                <p className="text-2xl font-mono text-emerald-400">{formatTime(stats.timeElapsed)}</p>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-xl">
                <p className="text-xs text-slate-500 uppercase font-bold">총 횟수</p>
                <p className="text-2xl font-mono text-blue-400">{stats.moves}</p>
              </div>
            </div>

            <button 
              onClick={() => setGameState('IDLE')}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold rounded-xl shadow-lg hover:brightness-110 transition-all"
            >
              다시 도전하기
            </button>
          </div>
        </div>
      )}

      {/* Footer Decoration */}
      <footer className="mt-auto pt-12 text-slate-600 text-xs text-center flex flex-col items-center gap-2">
        <div className="flex gap-4 mb-2">
          <i className="fas fa-flask"></i>
          <i className="fas fa-microscope"></i>
          <i className="fas fa-vial"></i>
        </div>
        <p>&copy; 2024 Chemistry Card Master. Powered by Gemini Flash.</p>
      </footer>
    </div>
  );
};

interface CardProps {
  card: CardInstance;
  onClick: () => void;
}

const Card: React.FC<CardProps> = ({ card, onClick }) => {
  const element = ELEMENTS.find(e => e.number === card.elementNumber);
  const bgColor = element?.color || 'bg-slate-500';

  return (
    <div 
      className={`relative h-24 md:h-32 aspect-[3/4] cursor-pointer perspective-1000 transition-transform duration-300 hover:scale-105 ${card.isMatched ? 'opacity-40 grayscale-[0.5]' : ''}`}
      onClick={onClick}
    >
      <div className={`relative w-full h-full transform-style-3d transition-transform duration-500 ${card.isFlipped || card.isMatched ? 'rotate-y-180' : ''}`}>
        
        {/* Card Front (Back of the actual card content) */}
        <div className="absolute inset-0 backface-hidden flex items-center justify-center bg-slate-700 border-2 border-slate-600 rounded-lg shadow-md">
          <div className="text-slate-500 text-xl md:text-3xl opacity-30">
            <i className="fas fa-atom"></i>
          </div>
        </div>

        {/* Card Back (Content Side) */}
        <div className={`absolute inset-0 backface-hidden rotate-y-180 flex flex-col items-center justify-center ${bgColor} border-2 border-white/20 rounded-lg shadow-lg p-2 overflow-hidden`}>
          <div className="absolute top-1 left-1 text-[8px] md:text-[10px] font-bold text-white/50">
            {card.elementNumber}
          </div>
          
          <div className={`font-bold text-white text-center leading-tight ${card.type === 'symbol' ? 'text-2xl md:text-4xl' : 'text-xs md:text-sm'}`}>
            {card.content}
          </div>
          
          <div className="mt-1 opacity-60 text-[8px] uppercase tracking-tighter text-white">
            {card.type === 'symbol' ? 'Symbol' : 'Name'}
          </div>

          {card.isMatched && (
            <div className="absolute inset-0 bg-white/10 flex items-center justify-center">
               <i className="fas fa-check-circle text-white/40 text-2xl"></i>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
