
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getElementFact(elementNameKr: string, elementSymbol: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `화학 원소 ${elementNameKr} (${elementSymbol})에 대한 흥미로운 상식이나 실생활 활용 예시를 1~2문장으로 짧고 친근하게 알려줘.`,
      config: {
        systemInstruction: "You are a friendly chemistry teacher who explains things simply and interestingly in Korean.",
      }
    });
    return response.text || "이 원소는 우리 주변에서 아주 중요한 역할을 한답니다!";
  } catch (error) {
    console.error("Error fetching element fact:", error);
    return "이 원소는 주기율표의 중요한 구성 요소입니다.";
  }
}
